import { WebSocketServer } from 'ws';
import fetch from 'node-fetch';

const wss = new WebSocketServer({ port: 8080 });
const sheetId = 'Your_Sheet_ID'; // Replace with your actual sheet ID
const apiKey = 'Your_API_Key'; // Replace with your actual API key

const url = `https://sheets.googleapis.com/v4/spreadsheets/${sheetId}/values/Sheet1!A:E?key=${apiKey}`;

const lapTimeToSeconds = (lapTime) => {
  const [hours, minutes, seconds] = lapTime.split(':').map(Number);
  return hours * 3600 + minutes * 60 + seconds;
};

const fetchSheetData = async () => {
  try {
    const response = await fetch(url);
    const data = await response.json();
    if (data.values) {
      const leaderboard = data.values.slice(1).map(row => ({
        Name: row[0],
        Region: row[1],
        Store: row[2],
        LapTime: row[3],
        Date: row[4],
        LapTimeInSeconds: lapTimeToSeconds(row[3])
      }));

      // Sort by lap time and assign ranks
      leaderboard.sort((a, b) => a.LapTimeInSeconds - b.LapTimeInSeconds);
      return leaderboard.map((entry, index) => ({
        Rank: index + 1,
        Name: entry.Name,
        Region: entry.Region,
        Store: entry.Store,
        LapTime: entry.LapTime,
        Date: entry.Date
      }));
    }
    return [];
  } catch (error) {
    console.error('Error fetching data:', error);
    return [];
  }
};

let leaderboardData = [];

// Update leaderboard data every 6 seconds
const updateLeaderboard = async () => {
  leaderboardData = await fetchSheetData();
  console.log("Updated leaderboard data:", leaderboardData); // Log to check updates

  // Broadcast the updated leaderboard data to all connected clients
  wss.clients.forEach(client => {
    if (client.readyState === client.OPEN) {
      console.log("Sending updated leaderboard to client");
      client.send(JSON.stringify(leaderboardData));
    }
  });
};

// Initial leaderboard update
updateLeaderboard();

// Update leaderboard data every 6 seconds
setInterval(updateLeaderboard, 6000);

wss.on('connection', ws => {
  // Send the full leaderboard data to new clients
  ws.send(JSON.stringify(leaderboardData));
});

console.log('WebSocket server is running on ws://localhost:8080');
